/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.project;

/**
 *
 * @author vodde
 */
public class Manager extends User{ 
    public Manager(String u, String p) 
    {
        super(u,p);
    } 
    
    @Override
    public void additionalFeePurchase(int p){
        
    }
}
